const form=document.querySelector("form"),
           nextBtn = document.querySelector(".nextBtn"),
           allInput=form.querySelectorAll(".first input");


