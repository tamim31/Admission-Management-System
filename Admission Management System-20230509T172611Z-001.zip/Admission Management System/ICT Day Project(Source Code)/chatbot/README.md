# Simple Chatbot
 Made with HTML, CSS, PHP, MySQLI & jQuery 

Database file included. 

Responds to simple messages like: 
* "*What is your name?*",
* "*Where are you from?*",
* "*Hello / Hi / Hey*",
* "*Awesome / Cool / nice*"

Test the simple chatbot [here](https://kasperofzeau.nl/Simple-Chatbot/)
