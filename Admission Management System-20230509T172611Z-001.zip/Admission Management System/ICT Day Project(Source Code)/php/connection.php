<?php
$server="localhost";
$username="root";
$password=" ";
$database="cl";
$conn=mysqli_connect('localhost','root','','cl') or die('connection failed');


?>

