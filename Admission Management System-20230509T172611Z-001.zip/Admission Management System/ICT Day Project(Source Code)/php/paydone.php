<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/paydone.css">
    <title>pay done</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
</head>

<body>
    

    <section class="experience-section7">
        <br><br><br><br>
    <center> <div class="half-width7 left-experience7">  
        <br><br>
            <center class="green-color"> Your payment is successfully done!</center><br>
            <center> Your roll number was send to your email.</center><br>


            <center><a href="login.php">Click here to login into your profile</a></center><br>
             </center>
         
       
            </div>
        </center>

    </section>
    
</body>

</html>
